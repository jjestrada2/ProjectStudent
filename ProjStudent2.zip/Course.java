

import java.util.ArrayList;

public class Course {

	private String name;
	private ArrayList<Student> rosterList;
	private ArrayList<Student> waitList;
	private int maxNumRosterList;
	private int maxNumWaitList;
	
	
	public Course(String name,int maxNumRosterList,int maxNumWaitList) {
		this.name=name;
		this.rosterList=new ArrayList<Student>();
		this.waitList=new ArrayList<Student>();
		this.maxNumRosterList=maxNumRosterList;
		this.maxNumWaitList=maxNumWaitList;
	}
	
	//getterSetter
	
	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public ArrayList<Student> getRosterList() {
		return rosterList;
	}

	/* roasterList Should be only modified by the method dropp and add Student 
	public void setRosterList(ArrayList<Student> rosterList) {
		this.rosterList = rosterList;
	}*/


	public ArrayList<Student> getWaitList() {
		return waitList;
	}

	/*waitList Should be only modified by the method dropp and add Student 
	public void setWaitList(ArrayList<Student> waitList) {
		this.waitList = waitList;
	}*/


	public int  getMaxEnrolled() {
		return maxNumRosterList;
	}


	public void setMaxNumRosterList(int maxNumRosterList) {
		if(maxNumRosterList>0) {
		this.maxNumRosterList = maxNumRosterList;
		}
	}


	public int getMaxWaitlist() {
		return maxNumWaitList;
	}


	public void setMaxNumWaitlist(int maxNumWaitlist) {
		if(maxNumWaitlist>0) {
		this.maxNumWaitList = maxNumWaitlist;
		}
	}
	
	public int getNumEnrolled() {
		return this.rosterList.size();
	}
	
	public int getNumWaitlist() {
		return this.waitList.size();
	}

	@Override
	public String toString() {
		return "---------------------------------------------------------------------------------------"+
				"\nCourse name: \t\t" + name +
	"\nRoster List Students: \t\t" + rosterList.size() + 
	"\nMaximum number in Roster List: \t"+ maxNumRosterList +
	"\nRoster List Students: \t\t"+ this.rosterList.toString()+
	"\nWaitlist Students: \t\t"+waitList.size()+
	"\nMaximum number in Waitlist: \t" + maxNumWaitList+
	"\nWaitList Students \t\t"+this.waitList.toString()+
	"\n---------------------------------------------------------------------------------------";
	}
	
	public boolean addStudent(Student student) {
		
		boolean isInRosterList=this.rosterList.contains(student);
		boolean isInWaitlist = this.waitList.contains(student);
		boolean isRoomInRoster = this.rosterList.size()<this.maxNumRosterList ? true : false;
		boolean isRoomInWait = this.waitList.size()<this.maxNumWaitList ? true : false;
		
		if(student.isTuitionPaid()&&(!isInRosterList)&&(!isInWaitlist)) {
			if(isRoomInRoster) {
				this.rosterList.add(student);
				return true;
			}else if(isRoomInWait) {
				this.waitList.add(student);
				return true;
			}else return false;
		}else {
			return false;
		}
	}
	
	public boolean dropStudent(Student student) {
		boolean isInRosterList=this.rosterList.contains(student);
		boolean isInWaitlist = this.waitList.contains(student);
		if(isInRosterList) {
			this.rosterList.remove(student);
			if(!this.waitList.isEmpty()) {
				this.rosterList.add(this.waitList.get(0));
				this.waitList.remove(0);
			}
			return true;
		}else if(isInWaitlist){
			this.waitList.remove(student);
			return true;
		}else {
			return false;
		}
	}
	
		
}
